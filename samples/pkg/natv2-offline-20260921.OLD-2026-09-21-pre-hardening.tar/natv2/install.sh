#!/usr/bin/env bash
###############################################################################
# NATv2 one-shot installer (Linux, Docker Compose) — ONLINE and OFFLINE.
#
#   tar xzf natv2-*.tar.gz && cd natv2 && sudo bash install.sh
#
# Mode is auto-detected:
#   * images/ directory present (offline package)  -> OFFLINE: nothing is
#     downloaded or built; Docker images are loaded from images/*.tar.gz and
#     Docker itself is installed from docker-offline/ if it is missing.
#   * otherwise                                    -> ONLINE: installs Docker
#     (get.docker.com) if missing, builds the app image, pulls the rest.
#
# It asks for the environment values, then: writes .env, starts NATS, creates
# the FRAMES_PREVIEW / FRAMES_V2 streams, starts the sandbox (web UI + API),
# creates connector tokens and starts receivers.
#
# Port / name conflicts: ports already in use on the machine are detected and
# the next free one is suggested; container names that belong to some other
# project are automatically suffixed. Nothing else on the host is touched.
#
# Flags:
#   --yes        don't prompt; use existing .env values or defaults
#                (busy ports are moved to the next free one automatically)
#   --env-only   only write .env, then exit (no Docker needed)
#   --offline    force offline mode      --online   force online mode
#   --reload     re-load the bundled images even if already present (offline)
# Safe to re-run: existing .env values become the defaults.
###############################################################################
set -euo pipefail
cd "$(dirname "$0")"

YES=0; ENV_ONLY=0; MODE=auto; RELOAD=0
for a in "$@"; do
  case "$a" in
    --yes|-y)   YES=1 ;;
    --env-only) ENV_ONLY=1 ;;
    --offline)  MODE=offline ;;
    --online)   MODE=online ;;
    --reload)   RELOAD=1 ;;
    -h|--help)  sed -n '2,32p' "$0"; exit 0 ;;
    *) echo "unknown flag: $a"; exit 1 ;;
  esac
done

say()  { printf '\n\033[1;36m== %s\033[0m\n' "$*"; }
ok()   { printf '   \033[32m✔\033[0m %s\n' "$*"; }
warn() { printf '   \033[33m!\033[0m %s\n' "$*"; }
die()  { printf '\n\033[31mERROR:\033[0m %s\n' "$*" >&2; exit 1; }

SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"
# Installing Docker, opening the firewall etc. needs root. Fail fast (never hang on a
# password prompt that nobody can answer, e.g. when run from a script or a pipe).
if [ "$ENV_ONLY" -eq 0 ] && [ -n "$SUDO" ]; then
  $SUDO -n true >/dev/null 2>&1 || die "root privileges are required. Re-run as:  sudo bash install.sh"
fi

# ── mode ─────────────────────────────────────────────────────────────────────
OFFLINE=0
case "$MODE" in
  offline) OFFLINE=1 ;;
  online)  OFFLINE=0 ;;
  auto)    if compgen -G "images/*.tar*" >/dev/null; then OFFLINE=1; fi ;;
esac
if [ "$OFFLINE" -eq 1 ] && ! compgen -G "images/*.tar*" >/dev/null; then
  die "--offline requested but images/ has no image archives (this is not the offline package)."
fi
[ "$OFFLINE" -eq 1 ] && say "OFFLINE mode (no downloads, no builds)" || say "ONLINE mode"

# host prerequisites — deliberately minimal (no curl/wget/python needed on the host)
[ "${BASH_VERSINFO[0]}" -ge 4 ] || die "bash 4+ is required (found $BASH_VERSION)."
missing=""
for c in awk sed grep tar cut tr head od date id; do command -v "$c" >/dev/null 2>&1 || missing="$missing $c"; done
[ -z "$missing" ] || die "missing basic tools on this host:$missing"

# ── helpers ──────────────────────────────────────────────────────────────────
env_get() {  # env_get KEY -> current value from .env (empty if none)
  [ -f .env ] || return 0
  grep -E "^$1=" .env | tail -1 | cut -d= -f2- | tr -d '\r' || true
}

ask() {      # ask VAR "Prompt" default
  local var="$1" prompt="$2" def="$3" ans=""
  if [ "$YES" -eq 0 ]; then read -r -p "  $prompt [$def]: " ans </dev/tty || true; fi
  printf -v "$var" '%s' "${ans:-$def}"
}

ask_yn() {   # ask_yn VAR "Prompt" Y|N
  local var="$1" prompt="$2" def="$3" ans=""
  if [ "$YES" -eq 0 ]; then read -r -p "  $prompt [$def]: " ans </dev/tty || true; fi
  ans="${ans:-$def}"
  case "$ans" in [Yy]*) printf -v "$var" '%s' 1 ;; *) printf -v "$var" '%s' 0 ;; esac
}

# NATS parses $NATS_AUTH_TOKEN as a config *value*: a token starting with a digit
# is read as a number, and true/false/yes/no/on/off as a boolean -> the server
# won't start. So tokens must start with a letter and not be one of those words.
valid_token() {
  [[ "$1" =~ ^[A-Za-z][A-Za-z0-9_-]*$ ]] && ! [[ "${1,,}" =~ ^(true|false|yes|no|on|off)$ ]]
}
gen_token() { echo "nats_$(openssl rand -hex 24 2>/dev/null || head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n')"; }

wait_healthy() {  # wait_healthy CONTAINER SECONDS  (uses the compose healthcheck; no host curl needed)
  local c="$1" n="$2" i=0 st
  while :; do
    st="$($DOCKER inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$c" 2>/dev/null || true)"
    [ "$st" = "healthy" ] && return 0
    i=$((i+1)); [ "$i" -ge "$n" ] && return 1; sleep 1
  done
}

tcp_open() { (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null; }   # host-side reachability of a published port

api() {  # talk to the sandbox API from inside its own container (which always has curl)
  $DOCKER exec "$SANDBOX_CNAME" curl -sf "$@"
}

set_env() {  # set_env KEY VALUE  (edit .env in place)
  if grep -qE "^$1=" .env; then sed -i "s|^$1=.*|$1=$2|" .env; else echo "$1=$2" >> .env; fi
}

# ── docker detection / installation ──────────────────────────────────────────
DOCKER="docker"; HAVE_DOCKER=0; DC=""
detect_docker() {
  command -v docker >/dev/null 2>&1 || return 1
  if docker info >/dev/null 2>&1; then DOCKER="docker"
  elif $SUDO docker info >/dev/null 2>&1; then DOCKER="$SUDO docker"
  else return 1; fi
  HAVE_DOCKER=1
}

ensure_docker() {
  if detect_docker; then :; else
    if command -v docker >/dev/null 2>&1; then
      warn "Docker is installed but the daemon is not reachable — trying to start it"
      $SUDO systemctl enable --now docker >/dev/null 2>&1 || true; sleep 3
    elif [ "$OFFLINE" -eq 1 ]; then
      [ -f docker-offline/install-docker.sh ] || die "Docker is not installed and this package has no docker-offline/ bundle. Install Docker manually, then re-run."
      warn "Docker not found — installing from docker-offline/ (no internet needed)"
      $SUDO bash docker-offline/install-docker.sh
    else
      warn "Docker not found — installing (get.docker.com)"
      command -v curl >/dev/null 2>&1 || { $SUDO apt-get update -y && $SUDO apt-get install -y curl; }
      curl -fsSL https://get.docker.com | $SUDO sh
      $SUDO systemctl enable --now docker
    fi
    detect_docker || die "Docker is installed but not usable (is the daemon running? try: sudo systemctl start docker)."
  fi
  if ! $DOCKER compose version >/dev/null 2>&1; then
    if [ "$OFFLINE" -eq 1 ]; then
      die "'docker compose' plugin is missing. Install it (docker-offline/ contains one) and re-run."
    fi
    $SUDO apt-get update -y && $SUDO apt-get install -y docker-compose-plugin
  fi
  DC="$DOCKER compose"
}

# ── port helpers ─────────────────────────────────────────────────────────────
OWN_PORTS=""   # host ports currently published by THIS project's own containers
TAKEN=""       # ports already chosen in this run
own_ports_refresh() {
  OWN_PORTS=""
  [ "$HAVE_DOCKER" -eq 1 ] || return 0
  OWN_PORTS="$($DOCKER ps --filter "label=com.docker.compose.project=$PROJECT" --format '{{.Ports}}' 2>/dev/null \
               | grep -oE ':[0-9]+->' | tr -d ':>-' | sort -u || true)"
}

listening_ports() {
  if command -v ss >/dev/null 2>&1; then ss -ltn 2>/dev/null | awk 'NR>1{n=split($4,a,":"); print a[n]}'
  elif command -v netstat >/dev/null 2>&1; then netstat -ltn 2>/dev/null | awk '{n=split($4,a,":"); print a[n]}'
  fi
}

port_busy() {  # 0 = busy with something that is NOT our own stack
  local p="$1" lp
  [ -z "${NATV2_SKIP_PORTCHECK:-}" ] || return 1
  if grep -qx "$p" <<<"$OWN_PORTS"; then return 1; fi
  if command -v ss >/dev/null 2>&1 || command -v netstat >/dev/null 2>&1; then
    lp="$(listening_ports)"; grep -qx "$p" <<<"$lp"
  else
    (exec 3<>"/dev/tcp/127.0.0.1/$p") 2>/dev/null
  fi
}

free_port() {  # free_port START [avoid...] -> first usable port >= START
  local p="$1" i=0; shift
  while [ "$i" -lt 500 ]; do
    if ! port_busy "$p"; then case " $* " in *" $p "*) ;; *) echo "$p"; return ;; esac; fi
    p=$((p+1)); i=$((i+1))
  done
  echo "$1"
}

PORT_NOTES=""
ask_port() {  # ask_port VAR "label" preferred
  local var="$1" label="$2" pref="$3" sug ans
  sug="$(free_port "$pref" $TAKEN)"
  if [ "$sug" != "$pref" ]; then
    warn "$label: port $pref is already in use on this machine -> suggesting $sug"
    PORT_NOTES="$PORT_NOTES\n   - $label: $pref was busy, using $sug"
  fi
  while :; do
    ans="$sug"
    if [ "$YES" -eq 0 ]; then read -r -p "  $label [$sug]: " ans </dev/tty || true; ans="${ans:-$sug}"; fi
    if ! [[ "$ans" =~ ^[0-9]+$ ]] || [ "$ans" -lt 1 ] || [ "$ans" -gt 65535 ]; then
      warn "not a valid port: $ans"; [ "$YES" -eq 1 ] && die "invalid port"; continue
    fi
    case " $TAKEN " in *" $ans "*) warn "$ans is already used by another NATv2 port"; [ "$YES" -eq 1 ] && die "duplicate port"; continue ;; esac
    if port_busy "$ans"; then
      warn "port $ans is in use on this machine"
      [ "$YES" -eq 1 ] && die "port $ans busy"; continue
    fi
    break
  done
  printf -v "$var" '%s' "$ans"; TAKEN="$TAKEN $ans"
}

# a container name owned by some OTHER project would make `compose up` fail
pick_name() {  # pick_name DEFAULT -> stdout: a name that is free or ours
  local def="$1" lbl
  if [ "$HAVE_DOCKER" -eq 1 ] && $DOCKER inspect "$def" >/dev/null 2>&1; then
    lbl="$($DOCKER inspect -f '{{index .Config.Labels "com.docker.compose.project"}}' "$def" 2>/dev/null || true)"
    if [ "$lbl" != "$PROJECT" ]; then echo "${def}-${PROJECT}"; return; fi
  fi
  echo "$def"
}

# ── 1. docker ────────────────────────────────────────────────────────────────
if [ "$ENV_ONLY" -eq 0 ]; then
  say "Docker"
  ensure_docker
  ok "$($DOCKER --version)"
  ok "$($DOCKER compose version | head -1)"
fi

PROJECT="${NATV2_PROJECT:-$(env_get COMPOSE_PROJECT_NAME)}"; PROJECT="${PROJECT:-natv2}"
own_ports_refresh

# ── 2. questions ─────────────────────────────────────────────────────────────
say "Configuration"
def_ip="$(env_get API_HOST)"
# best guess of the LAN address: source IP of the default route; else the first global
# IPv4 that is not a container/virtual bridge (docker0, br-*, veth*, ...); else loopback
[ -n "$def_ip" ] || def_ip="$( (ip -4 route get 1.1.1.1 2>/dev/null | sed -n 's/.* src \([0-9.]*\).*/\1/p') || true)"
[ -n "$def_ip" ] || def_ip="$( (ip -o -4 addr show scope global 2>/dev/null     | awk '$2 !~ /^(docker|br-|veth|virbr|cni|flannel|cali|kube|lo)/ {print $4}' | cut -d/ -f1 | head -1) || true)"
def_tok="$(env_get NATS_AUTH_TOKEN)"
valid_token "$def_tok" || def_tok="$(gen_token)"   # empty or unusable old value -> new one

ask SERVER_IP  "Server IP that cameras/receivers will use"                 "${def_ip:-127.0.0.1}"
ask NATS_TOKEN "NATS auth token (start with a letter; letters/digits/-/_)" "$def_tok"
d="$(env_get NATS_CLIENT_PORT)"; ask_port NATS_PORT "NATS client port"    "${d:-4222}"
d="$(env_get NATS_HTTP_PORT)";   ask_port NATS_HTTP "NATS monitoring port" "${d:-8222}"
d="$(env_get API_PORT)";         ask_port API_PORT  "Web UI / API port"    "${d:-9000}"
d="$(env_get QUEUE_GROUP)";      ask QGROUP "Receiver queue group"         "${d:-frame_workers}"

WANT_RECV=0; WANT_AUTO=0; WANT_YOLO=0
if [ "$ENV_ONLY" -eq 0 ]; then
  ask_yn WANT_RECV  "Start receivers?"                              Y
  d="$(env_get RECEIVER_REPLICAS)"; REPLICAS="${d:-2}"
  if [ "$WANT_RECV" -eq 1 ]; then ask REPLICAS "How many receiver containers" "$REPLICAS"; fi
  ask_yn WANT_AUTO  "Start auto-scaler?"                            N
  if [ "$OFFLINE" -eq 1 ] && ! compgen -G "images/natv2-yolo*.tar*" >/dev/null; then
    warn "YOLO image is not part of this offline package — YOLO skipped"
  else
    ask_yn WANT_YOLO "Start YOLO pipeline (heavy, needs CPU/GPU)?"  N
  fi
fi

valid_token "$NATS_TOKEN" || die "Invalid token. It must start with a letter, contain only letters/digits/'-'/'_' (it is embedded in a URL), and not be true/false/yes/no/on/off. Example: nats_9f3a1c"

# container names (avoid clashes with other projects on this host)
NATS_CNAME="$(env_get NATS_CONTAINER_NAME)";         NATS_CNAME="$(pick_name "${NATS_CNAME:-nats-jetstream}")"
SANDBOX_CNAME="$(env_get SANDBOX_CONTAINER_NAME)";   SANDBOX_CNAME="$(pick_name "${SANDBOX_CNAME:-natv2-sandbox}")"
AUTOSCALE_CNAME="$(env_get AUTOSCALE_CONTAINER_NAME)"; AUTOSCALE_CNAME="$(pick_name "${AUTOSCALE_CNAME:-natv2-autoscale}")"
YOLO_CNAME="$(env_get YOLO_CONTAINER_NAME)";         YOLO_CNAME="$(pick_name "${YOLO_CNAME:-natv2-yolo}")"
for n in "$NATS_CNAME:nats-jetstream" "$SANDBOX_CNAME:natv2-sandbox"; do
  [ "${n%%:*}" = "${n##*:}" ] || warn "container name ${n##*:} is taken by another project -> using ${n%%:*}"
done

# ── 3. write .env ────────────────────────────────────────────────────────────
say "Writing .env"
if [ -f .env ]; then cp .env ".env.bak.$(date +%s)"; ok "old .env backed up"; fi
KEEP_TOKEN="$(env_get TOKEN)"; KEEP_AUTO="$(env_get AUTOSCALE_TOKEN)"
REPLICAS="${REPLICAS:-$(env_get RECEIVER_REPLICAS)}"; REPLICAS="${REPLICAS:-2}"
cat > .env <<EOF
# Generated by install.sh on $(date -u +%FT%TZ)
COMPOSE_PROJECT_NAME=$PROJECT

# ── NATS ───────────────────────────────────────────────
NATS_AUTH_TOKEN=$NATS_TOKEN
NATS_HOST=$SERVER_IP
NATS_CLIENT_PORT=$NATS_PORT
NATS_HTTP_PORT=$NATS_HTTP
NATS_URL=nats://$NATS_TOKEN@$SERVER_IP:$NATS_PORT

# ── Web UI / API ───────────────────────────────────────
API_HOST=$SERVER_IP
API_PORT=$API_PORT
API_URL=http://$SERVER_IP:$API_PORT

# ── Container names (auto-suffixed if another project owns the default) ──
NATS_CONTAINER_NAME=$NATS_CNAME
SANDBOX_CONTAINER_NAME=$SANDBOX_CNAME
AUTOSCALE_CONTAINER_NAME=$AUTOSCALE_CNAME
YOLO_CONTAINER_NAME=$YOLO_CNAME

# ── Connector tokens (created automatically by install.sh) ──
TOKEN=$KEEP_TOKEN
AUTOSCALE_TOKEN=$KEEP_AUTO
QUEUE_GROUP=$QGROUP
RECEIVER_REPLICAS=$REPLICAS
EOF
chmod 600 .env
ok ".env written"
[ "$ENV_ONLY" -eq 1 ] && { cat .env; exit 0; }

# ── 4. images ────────────────────────────────────────────────────────────────
if [ "$OFFLINE" -eq 1 ]; then
  say "Loading Docker images from images/ (offline)"
  have_all=1
  for img in natv2-app:latest nats:alpine natsio/nats-box:latest; do
    $DOCKER image inspect "$img" >/dev/null 2>&1 || have_all=0
  done
  if [ "$have_all" -eq 1 ] && [ "$RELOAD" -eq 0 ]; then
    ok "images already present (use --reload to force)"
  else
    for f in images/natv2-images.tar.gz images/natv2-images.tar; do
      if [ -f "$f" ]; then $DOCKER load -i "$f" | sed 's/^/   /'; break; fi
    done
  fi
  if [ "$WANT_YOLO" -eq 1 ] && ! $DOCKER image inspect natv2-yolo:latest >/dev/null 2>&1; then
    for f in images/natv2-yolo.tar.gz images/natv2-yolo.tar; do
      if [ -f "$f" ]; then $DOCKER load -i "$f" | sed 's/^/   /'; break; fi
    done
  fi
  for img in natv2-app:latest nats:alpine natsio/nats-box:latest; do
    $DOCKER image inspect "$img" >/dev/null 2>&1 || die "image $img is missing after load — is images/ complete?"
  done
  ok "images ready"
  UP_FLAGS="--no-build --pull never"
else
  UP_FLAGS="--build"
fi

# ── 5. NATS ──────────────────────────────────────────────────────────────────
say "Starting NATS"
if [ "$OFFLINE" -eq 1 ]; then $DC up -d --pull never nats; else $DC up -d nats; fi
if ! wait_healthy "$NATS_CNAME" 90; then
  $DOCKER logs --tail 30 "$NATS_CNAME" || true
  die "NATS did not become healthy (log above)."
fi
ok "NATS healthy (host port :$NATS_PORT)"

# ── 6. JetStream streams ─────────────────────────────────────────────────────
say "JetStream streams"
NATSCLI() { $DOCKER run --rm --network host natsio/nats-box:latest nats --server "nats://$NATS_TOKEN@127.0.0.1:$NATS_PORT" "$@"; }

# The old SANDBOX stream (frames.>) overlaps the new streams. It is only a
# 60-second, in-memory preview cache, so it is safe to drop.
if NATSCLI stream info SANDBOX >/dev/null 2>&1; then
  warn "removing legacy SANDBOX stream (overlaps FRAMES_*; memory-only 60s cache)"
  NATSCLI stream rm SANDBOX -f >/dev/null
fi
if NATSCLI stream info FRAMES_PREVIEW >/dev/null 2>&1; then
  ok "FRAMES_PREVIEW exists — left unchanged"
else
  NATSCLI stream add FRAMES_PREVIEW --subjects "frames.preview.>" --storage memory \
    --max-msgs-per-subject 1 --retention limits --discard old --replicas 1 --defaults >/dev/null
  ok "FRAMES_PREVIEW created"
fi
if NATSCLI stream info FRAMES_V2 >/dev/null 2>&1; then
  ok "FRAMES_V2 exists — left unchanged"
else
  NATSCLI stream add FRAMES_V2 --subjects "frames.v2.>" --storage file \
    --max-msgs-per-subject 100 --max-age 6h --retention limits --discard old --replicas 1 --defaults >/dev/null
  ok "FRAMES_V2 created"
fi

# ── 7. sandbox (web UI + API) ────────────────────────────────────────────────
say "Starting sandbox (web UI + API)"
$DC up -d $UP_FLAGS sandbox
if ! wait_healthy "$SANDBOX_CNAME" 120; then
  $DC logs --tail 40 sandbox || true
  die "Sandbox did not become healthy (log above)."
fi
ok "web UI up (host port :$API_PORT)"

# ── 8. connector tokens ──────────────────────────────────────────────────────
mk_connector() {  # mk_connector NAME -> prints token
  api -X POST "http://localhost:9000/api/connectors" -H 'Content-Type: application/json' \
    -d "{\"name\":\"$1\",\"tags\":[],\"max_cams\":0,\"queue_group\":\"$QGROUP\"}" \
    | sed -n 's/.*"token":"\([^"]*\)".*/\1/p' || true
}
have_connector() {  # have_connector TOKEN -> 0 if the API knows this token
  local body
  [ -n "$1" ] || return 1
  body="$(api "http://localhost:9000/api/connectors" || true)"
  grep -q "$1" <<<"$body"
}
if [ "$WANT_RECV" -eq 1 ] || [ "$WANT_AUTO" -eq 1 ] || [ "$WANT_YOLO" -eq 1 ]; then
  say "Connector tokens"
  if ! have_connector "$(env_get TOKEN)"; then
    t="$(mk_connector "Production Workers")"; [ -n "$t" ] || die "could not create connector token"
    set_env TOKEN "$t"; ok "receiver token created"
  fi
  if [ "$WANT_AUTO" -eq 1 ] && ! have_connector "$(env_get AUTOSCALE_TOKEN)"; then
    t="$(mk_connector "Autoscaler")"; [ -n "$t" ] || die "could not create autoscaler token"
    set_env AUTOSCALE_TOKEN "$t"; ok "autoscaler token created"
  fi
fi

# ── 9. receivers / autoscaler / yolo ─────────────────────────────────────────
PROFILES=""
if [ "$WANT_AUTO" -eq 1 ]; then PROFILES="--profile full"
elif [ "$WANT_RECV" -eq 1 ]; then PROFILES="--profile receivers"; fi
[ "$WANT_YOLO" -eq 1 ] && PROFILES="$PROFILES --profile yolo"
if [ -n "$PROFILES" ]; then
  say "Starting workers"
  $DC $PROFILES up -d $UP_FLAGS
fi

# ── 10. firewall (only if ufw is active) ─────────────────────────────────────
if command -v ufw >/dev/null 2>&1 && $SUDO ufw status 2>/dev/null | grep -q "Status: active"; then
  say "Firewall (ufw)"
  $SUDO ufw allow "$NATS_PORT/tcp" >/dev/null; $SUDO ufw allow "$API_PORT/tcp" >/dev/null
  ok "opened $NATS_PORT/tcp (NATS) and $API_PORT/tcp (UI)"
fi

# ── done ─────────────────────────────────────────────────────────────────────
say "Checking published ports (from this host)"
for pp in "NATS:$NATS_PORT" "Web UI:$API_PORT"; do
  if tcp_open "${pp##*:}"; then ok "${pp%%:*} port ${pp##*:} is reachable"; else warn "${pp%%:*} port ${pp##*:} did not answer on 127.0.0.1"; fi
done
say "Done"
$DC $PROFILES ps
if [ -n "$PORT_NOTES" ]; then
  printf '\n  Ports were moved because the defaults were busy on this machine:'
  printf '%b\n' "$PORT_NOTES"
fi
cat <<EOF

  Web UI ............ http://$SERVER_IP:$API_PORT
  NATS (for sender) . nats://$NATS_TOKEN@$SERVER_IP:$NATS_PORT
  Sender must publish JPEG frames (<1 MB) to:
      frames.preview.<src>.<zone>.<scene>.<cam>   -> FRAMES_PREVIEW
      frames.v2.<src>.<zone>.<scene>.<cam>        -> FRAMES_V2
  (<src> = sender IP with underscores, e.g. 192_168_18_50)

  Logs ....... $DC logs -f sandbox
  Stop ....... $DC down
  Re-run ..... sudo bash install.sh   (existing values become defaults)
EOF

#!/bin/bash
echo "[stub nats-deploy] ran"

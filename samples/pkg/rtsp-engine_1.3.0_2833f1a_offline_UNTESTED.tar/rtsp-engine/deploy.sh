#!/bin/bash
# ==============================================================================
# RTSP Snapshot Engine — Interactive Deploy Script
#
# Usage:
#   tar xzf rtsp-engine.tar.gz
#   cd rtsp-engine
#   bash deploy.sh                 # asks the few questions it needs, then builds + starts
#   bash deploy.sh --yes           # no questions: use .env / defaults (auto-picks free ports)
#   bash deploy.sh --interactive   # read the answers from stdin instead of a terminal
#
# What it asks (all have sensible defaults - just press Enter):
#   1. Which port the web UI/API should use on this machine.
#      If it is already taken, that process is LEFT ALONE and a free port is offered.
#   2. NATS: (1) connect to a NATS server you already have (host/port/credentials),
#            (2) install a NATS server on this machine too (bundled nats-deploy/),
#            (3) skip - enter it later in the web UI.
#   3. This machine's IP (the source the NATS hub identifies this engine by).
#
# What it does:
#   - creates .env, checks ports, builds (or, from an OFFLINE bundle, loads) the image
#     and starts the container (restart: always), waits for the health check, then
#     prepares the admin account (password printed ONCE, must be changed at first
#     sign-in) and applies your NATS details through the engine's CLI inside the
#     container (verified before they are saved)
#   - OFFLINE bundle (images/ folder present): needs no internet at all - the Docker
#     images are loaded from images/ and nothing is built or pulled
#   - never stops, restarts, renames or reconfigures anything else on the host: if a
#     container name or Compose project name is already taken by something else, new
#     names are chosen instead
#   - if Docker is missing it installs it first (from the bundled files in the OFFLINE package,
#     or with Docker's official installer in the online package) - run with sudo for that
# ==============================================================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
ok()   { printf "${GREEN}[OK]${NC} %s\n" "$*"; }
warn() { printf "${YELLOW}[!]${NC} %s\n" "$*"; }
info() { printf "${BLUE}[..]${NC} %s\n" "$*"; }
err()  { printf "${RED}[X]${NC} %s\n" "$*" >&2; exit 1; }

SCRIPT_DIR_LOGICAL="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"    # path as typed (may contain symlinks)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"          # physical path
cd "$SCRIPT_DIR"

# ---------- Mode ----------
INTERACTIVE=false
[ -t 0 ] && INTERACTIVE=true
for a in "$@"; do
    case "$a" in
        -y|--yes) INTERACTIVE=false ;;
        --interactive) INTERACTIVE=true ;;
        -h|--help) sed -n '2,/^set -/p' "$0" | sed '$d' | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) err "Unknown option '$a' (try --help)." ;;
    esac
done

CONTAINER_NAME="rtsp-engine"   # may be changed by resolve_names if that name is taken by something else
NATS_CONTAINER="rtsp-nats"

# ---------- Helpers ----------
env_get() { grep -E "^$1=" "${2:-.env}" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '[:space:]' || true; }
env_set() {                                    # env_set KEY VALUE [file]
    local f="${3:-.env}" tmp; tmp=$(mktemp)
    grep -vE "^$1=" "$f" > "$tmp" || true
    printf '%s=%s\n' "$1" "$2" >> "$tmp"
    cat "$tmp" > "$f"; rm -f "$tmp"
}

# ask "Question" "default" -> sets REPLY (default used when non-interactive or Enter)
ask() {
    local q="$1" def="${2:-}"
    if [ "$INTERACTIVE" = true ]; then
        if [ -n "$def" ]; then read -r -p "    $q [$def]: " REPLY || REPLY=""; else read -r -p "    $q: " REPLY || REPLY=""; fi
        REPLY="${REPLY:-$def}"
    else
        REPLY="$def"
    fi
}
ask_secret() {
    if [ "$INTERACTIVE" = true ]; then
        if [ -t 0 ]; then read -r -s -p "    $1: " REPLY || REPLY=""; echo; else read -r -p "    $1: " REPLY || REPLY=""; fi
    else REPLY=""; fi
}

valid_ipv4() {
    local IFS=. x; local -a o=($1)
    [ "${#o[@]}" -eq 4 ] || return 1
    for x in "${o[@]}"; do [[ "$x" =~ ^(0|[1-9][0-9]{0,2})$ ]] && [ "$x" -le 255 ] || return 1; done
}

# --- ownership of containers / compose projects (never touch what we did not create) ---
# Every install gets a random INSTALL_ID in its .env; compose stamps it on the container as a
# label. "Is this container mine?" is then a plain ID comparison - no folder-path matching,
# which is unreliable (symlinks, Windows/WSL path forms, moved folders).
new_install_id() { od -An -N12 -tx1 /dev/urandom 2>/dev/null | tr -d ' \n' || printf '%s%s' "$$" "$(date +%s)"; }
c_label() { docker container inspect -f "{{index .Config.Labels \"$2\"}}" "$1" 2>/dev/null || true; }
# is_ours CONTAINER INSTALL_ID DIR_PHYSICAL DIR_LOGICAL
is_ours() {
    local lbl wd
    lbl=$(c_label "$1" com.rtsp-engine.install-id)
    if [ -n "$lbl" ]; then [ "$lbl" = "$2" ]; return; fi
    # container from an older version of this installer (no id label): fall back to its folder
    wd=$(c_label "$1" com.docker.compose.project.working_dir)
    [ -n "$wd" ] && { [ "$wd" = "$3" ] || [ "$wd" = "$4" ]; }
}
# the project name docker compose derives from a folder name
default_project() { basename "$1" | tr 'A-Z' 'a-z' | sed 's/[^a-z0-9_-]/-/g; s/^[^a-z0-9]*//'; }
# resolve_names DIR_PHYSICAL DIR_LOGICAL ENVFILE KEY DEFAULT -> sets RESOLVED_NAME (container name to use)
# Two installs must never share a container name or a compose project name: compose would
# otherwise "adopt" the other install's containers and recreate (i.e. replace) them.
resolve_names() {
    local dirp="$1" dirl="$2" envf="$3" key="$4" def="$5" iid name n proj id
    iid=$(env_get INSTALL_ID "$envf")
    if [ -z "$iid" ]; then iid=$(new_install_id); env_set INSTALL_ID "$iid" "$envf"; fi

    name=$(env_get "$key" "$envf"); name="${name:-$def}"
    if docker container inspect "$name" >/dev/null 2>&1 && ! is_ours "$name" "$iid" "$dirp" "$dirl"; then
        n=2; while docker container inspect "${def}-${n}" >/dev/null 2>&1; do n=$((n + 1)); done
        warn "A container named '${name}' already exists and belongs to something else - leaving it alone, using '${def}-${n}'."
        name="${def}-${n}"
    fi
    env_set "$key" "$name" "$envf"
    RESOLVED_NAME="$name"

    if [ -z "$(env_get COMPOSE_PROJECT_NAME "$envf")" ]; then
        proj=$(default_project "$dirp")
        for id in $(docker ps -aq --filter "label=com.docker.compose.project=$proj" 2>/dev/null); do
            if ! is_ours "$id" "$iid" "$dirp" "$dirl"; then
                warn "Another Docker Compose project named '${proj}' (from a different folder) is running - using a separate project name so it is never touched."
                env_set COMPOSE_PROJECT_NAME "${proj}-$(printf '%s' "$dirp" | cksum | cut -d' ' -f1)" "$envf"
                break
            fi
        done
    fi
}

valid_port() { [[ "$1" =~ ^[0-9]+$ ]] && [ "$1" -ge 1 ] && [ "$1" -le 65535 ]; }

# true if something on this host is listening on the port
port_in_use() {
    local p="$1"
    if command -v ss >/dev/null 2>&1; then
        ss -H -ltn "sport = :${p}" 2>/dev/null | grep -q . && return 0
    elif command -v lsof >/dev/null 2>&1; then
        lsof -iTCP:"${p}" -sTCP:LISTEN >/dev/null 2>&1 && return 0
    elif command -v netstat >/dev/null 2>&1; then
        netstat -ltn 2>/dev/null | grep -qE "[:.]${p}[[:space:]]" && return 0
    fi
    # Tool-independent double check: does anything accept a connection there?
    (exec 3<>"/dev/tcp/127.0.0.1/${p}") >/dev/null 2>&1 && return 0
    return 1
}

# host ports a container of ours already publishes (safe to reuse: redeploy replaces it)
ours_ports() { docker port "$1" 2>/dev/null | sed -E 's/.*:([0-9]+)$/\1/' | sort -u || true; }

# port_usable PORT OURS_LIST -> 0 if free, or held by our own container
port_usable() { grep -qx "$1" <<< "$2" && return 0; port_in_use "$1" && return 1; return 0; }

# next_free START OURS_LIST [AVOID] -> first usable port >= START (scans 100 ports)
next_free() {
    local p="$1" ours="$2" avoid="${3:-}" end=$(( $1 + 100 ))
    for ((; p <= end && p <= 65535; p++)); do
        [ "$p" = "$avoid" ] && continue
        port_usable "$p" "$ours" && { echo "$p"; return 0; }
    done
    return 1
}

# choose_port "Label" DEFAULT OURS_LIST [AVOID] -> echoes the chosen, verified-free port.
# Interactive: asks, re-asks while the answer is taken (suggesting the next free one).
# Non-interactive: silently takes the next free port from DEFAULT.
choose_port() {
    local label="$1" want="$2" ours="$3" avoid="${4:-}" suggestion
    while true; do
        valid_port "$want" || { [ "$INTERACTIVE" = true ] && { warn "'$want' is not a valid port (1-65535)." >&2; ask "$label" "8080" >&2; want="$REPLY"; continue; } || err "Invalid port '$want'."; }
        if [ "$want" != "$avoid" ] && port_usable "$want" "$ours"; then echo "$want"; return 0; fi
        suggestion=$(next_free "$((want + 1))" "$ours" "$avoid") || err "No free port found near ${want}. Nothing was changed."
        warn "Port ${want} is already in use by another process — leaving it alone." >&2
        if [ "$INTERACTIVE" = true ]; then
            ask "$label (suggested free port)" "$suggestion" >&2; want="$REPLY"
        else
            info "Using free port ${suggestion} instead." >&2; echo "$suggestion"; return 0
        fi
    done
}

detect_host_ip() {
    local ip=""
    ip=$(hostname -I 2>/dev/null | awk '{print $1}') || true
    [ -n "$ip" ] || ip=$(ip route get 1.1.1.1 2>/dev/null | sed -n 's/.*src \([0-9.]*\).*/\1/p') || true
    echo "$ip"
}

# ---------- Pre-flight: Docker ----------
docker_ready() { command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; }

install_docker() {
    [ "$(id -u)" -eq 0 ] || err "Docker is not installed and installing it needs root. Run again as:  sudo bash deploy.sh"
    if [ -d docker-offline ]; then
        info "Installing Docker from the files bundled in this package (no internet needed) ..."
        bash scripts/install-docker-offline.sh || err "Installing Docker from the bundle failed - see the output above."
    else
        info "Downloading Docker's official install script (get.docker.com) - needs internet ..."
        local tmp; tmp=$(mktemp)
        if command -v curl >/dev/null 2>&1; then curl -fsSL https://get.docker.com -o "$tmp"
        elif command -v wget >/dev/null 2>&1; then wget -qO "$tmp" https://get.docker.com
        else err "Neither curl nor wget is available to download Docker's installer."; fi \
            || err "Could not download Docker's installer (no internet?). On a machine without internet use the OFFLINE package - it includes Docker."
        sh "$tmp" || err "Docker's installer failed - see the output above."
        rm -f "$tmp"
        systemctl enable --now docker >/dev/null 2>&1 || true
    fi
}

if ! docker_ready; then
    if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
        err "Docker is installed but the daemon is not reachable. Is it running (systemctl start docker), and does this user have access (try: sudo bash deploy.sh)?"
    fi
    warn "Docker (with the compose plugin) is not installed on this machine."
    if [ "$INTERACTIVE" = true ]; then
        if [ -d docker-offline ]; then ask "Install it now from the bundled files? (y/n)" "y"; else ask "Install it now with Docker's official installer? (y/n)" "y"; fi
        case "$REPLY" in y|Y|yes|YES) ;; *) err "Docker is required. Install it (or accept the installation) and re-run." ;; esac
    else
        info "Non-interactive mode: installing Docker."
    fi
    install_docker
    docker_ready || err "Docker is still not usable after the installation."
    ok "Docker is ready."
fi

echo ""
echo "=== RTSP Snapshot Engine — setup ==="
[ "$INTERACTIVE" = true ] || info "Non-interactive mode: using .env / defaults."

# ---------- 1. Prepare .env ----------
if [ ! -f .env ]; then
    cp .env.example .env
    chmod 600 .env
    ok "Created .env from .env.example"
else
    ok "Using existing .env"
fi

# ---------- 1b. Container / project names (never collide with other installs) ----------
resolve_names "$SCRIPT_DIR" "$SCRIPT_DIR_LOGICAL" .env CONTAINER_NAME rtsp-engine
CONTAINER_NAME="$RESOLVED_NAME"
# Where this install lives: the web UI (Dashboard -> CPU capacity -> How to apply) prints copy-paste commands
# for the host with it. Detected here, on every run, so a moved folder is picked up.
env_set ENGINE_INSTALL_DIR "$SCRIPT_DIR"
# A CPU / memory limit set earlier (rtsp-engine-ctl, the web UI commands) lives in .env: an upgrade keeps it.
for _k in ENGINE_CPUS ENGINE_MEM; do
    [ -n "$(env_get $_k)" ] && ok "Keeping $_k=$(env_get $_k) from the existing .env"
done

# ---------- 1c. Offline bundle: load the Docker images, no internet needed ----------
OFFLINE=false
if [ -f images/MANIFEST ] && [ -f images/rtsp-engine.tar.gz ]; then
    OFFLINE=true
    ENGINE_IMAGE=$(env_get ENGINE_IMAGE images/MANIFEST)
    BUNDLE_ARCH=$(env_get ARCH images/MANIFEST)
    NATS_IMAGE=$(env_get NATS_IMAGE images/MANIFEST)
    [ -n "$ENGINE_IMAGE" ] || err "images/MANIFEST is incomplete (no ENGINE_IMAGE)."
    HOST_ARCH=$(docker info --format '{{.Architecture}}' 2>/dev/null || true)
    if [ -n "$BUNDLE_ARCH" ] && [ -n "$HOST_ARCH" ] && [ "$BUNDLE_ARCH" != "$HOST_ARCH" ]; then
        err "This offline bundle was built for ${BUNDLE_ARCH} but this machine is ${HOST_ARCH}. Build a bundle on a matching machine (scripts/build-offline.sh)."
    fi
    ok "Offline bundle detected (images/): no internet, build or pull needed."
    if [ -f images/SHA256SUMS ]; then
        info "Verifying image checksums ..."
        (cd images && sha256sum -c SHA256SUMS --quiet) || err "Image checksum mismatch - the bundle is corrupted or incomplete. Re-copy it."
        ok "Checksums OK."
    fi
    if docker image inspect "$ENGINE_IMAGE" >/dev/null 2>&1; then
        ok "Engine image ${ENGINE_IMAGE} already loaded."
    else
        info "Loading engine image (this can take a minute) ..."
        docker load -i images/rtsp-engine.tar.gz >/dev/null || err "docker load failed for images/rtsp-engine.tar.gz."
        ok "Loaded ${ENGINE_IMAGE}."
    fi
    # a dedicated tag: never overwrite another install's rtsp-engine:latest
    env_set ENGINE_IMAGE "$ENGINE_IMAGE"
fi

PORT=$(env_get PORT); PORT="${PORT:-8080}"           # port INSIDE the container (rarely needs changing)
valid_port "$PORT" || err "PORT='$PORT' in .env is not a valid port."
PREF=$(env_get HOST_PORT); PREF="${PREF:-$PORT}"     # preferred port on the host
OURS=$(ours_ports "$CONTAINER_NAME")

# ---------- 2. Web UI port ----------
echo ""
echo "── 1/4  Web UI port ─────────────────────────────────────────"
echo "    The port you will open in the browser (http://<this-machine>:PORT)."
ask "Web UI port" "$PREF"
HOST_PORT=$(choose_port "Web UI port" "$REPLY" "$OURS")
grep -qx "$HOST_PORT" <<< "$OURS" && info "Port ${HOST_PORT} is held by this app's own container — it will be replaced on redeploy."
env_set HOST_PORT "$HOST_PORT"
ok "Web UI will be on port ${HOST_PORT}."

# ---------- 3. NATS ----------
echo ""
echo "── 2/4  NATS (where frames are published) ───────────────────"
NATS_MODE="skip"; NATS_HOST=""; NATS_PORT_V="4222"; NATS_USER=""; NATS_PASS=""
EXISTING_NATS=$(env_get NATS_URL)

if [ -n "$EXISTING_NATS" ]; then
    info "NATS_URL is already set in .env — the engine will use it (a URL saved in the web UI would override it)."
    NATS_MODE="env"
else
    echo "    1) I already have a NATS server (JetStream enabled) — enter its address"
    echo "    2) Install a NATS server on THIS machine now (bundled, Docker)"
    echo "    3) Skip — I'll enter NATS details in the web UI"
    ask "Choose 1, 2 or 3" "3"
    case "$REPLY" in
        1) NATS_MODE="existing" ;;
        2) NATS_MODE="install" ;;
        *) NATS_MODE="skip" ;;
    esac
fi

if [ "$NATS_MODE" = "existing" ]; then
    TRIES=0
    while true; do
        TRIES=$((TRIES + 1)); [ "$TRIES" -le 5 ] || err "No NATS host given. Re-run, or choose option 3 and set it in the web UI."
        ask "NATS host / IP" ""; NATS_HOST="$REPLY"
        [ -n "$NATS_HOST" ] || { warn "Host is required (or choose option 3 to skip)."; continue; }
        case "$NATS_HOST" in
            localhost|127.*|::1)
                warn "'$NATS_HOST' would point at the engine's own container, not this machine. Use this machine's LAN IP or a hostname."
                [ "$INTERACTIVE" = true ] && continue ;;
        esac
        break
    done
    ask "NATS port" "4222"; NATS_PORT_V="$REPLY"
    valid_port "$NATS_PORT_V" || err "Invalid NATS port '$NATS_PORT_V'."
    ask "NATS username (optional)" ""; NATS_USER="$REPLY"
    if [ -n "$NATS_USER" ]; then ask_secret "NATS password (optional)"; NATS_PASS="$REPLY"; fi
fi

if [ "$NATS_MODE" = "install" ]; then
    [ -f nats-deploy/docker-compose.yml ] || err "nats-deploy/ is missing from this package — cannot install NATS here."
    [ -f nats-deploy/.env ] || cp nats-deploy/.env.example nats-deploy/.env
    resolve_names "$SCRIPT_DIR/nats-deploy" "$SCRIPT_DIR_LOGICAL/nats-deploy" nats-deploy/.env NATS_CONTAINER_NAME rtsp-nats
    NATS_CONTAINER="$RESOLVED_NAME"
    NATS_OURS=$(ours_ports "$NATS_CONTAINER")
    if [ "$OFFLINE" = true ] && [ -f images/nats.tar.gz ]; then
        if docker image inspect "${NATS_IMAGE:-nats:2.10-alpine}" >/dev/null 2>&1; then
            ok "NATS image already present."
        else
            info "Loading NATS image ..."
            docker load -i images/nats.tar.gz >/dev/null || err "docker load failed for images/nats.tar.gz."
        fi
    fi
    N_PREF=$(env_get NATS_PORT nats-deploy/.env); N_PREF="${N_PREF:-4222}"
    M_PREF=$(env_get NATS_MONITOR_PORT nats-deploy/.env); M_PREF="${M_PREF:-8222}"
    ask "NATS client port" "$N_PREF"
    NATS_PORT_V=$(choose_port "NATS client port" "$REPLY" "$NATS_OURS" "$HOST_PORT")
    ask "NATS monitoring port (localhost only)" "$M_PREF"
    NATS_MON=$(choose_port "NATS monitoring port" "$REPLY" "$NATS_OURS" "$NATS_PORT_V")
    env_set NATS_PORT "$NATS_PORT_V" nats-deploy/.env
    env_set NATS_MONITOR_PORT "$NATS_MON" nats-deploy/.env
    DETECTED=$(detect_host_ip)
    ask "This machine's LAN IP (the engine reaches NATS through it)" "$DETECTED"
    NATS_HOST="$REPLY"
    [ -n "$NATS_HOST" ] || err "Need this machine's IP to point the engine at NATS."
    ok "NATS will be installed on ports ${NATS_PORT_V} (client) / ${NATS_MON} (monitoring)."
fi

# ---------- 3b. This engine's IP (the <source> token in NATS subjects) ----------
echo ""
echo "── 3/4  This machine's IP address ───────────────────────────"
echo "    The NATS hub identifies this engine by IP (subjects look like frames.v2.192_168_18_50.<zone>.<scene>.<camera>)."
echo "    Use the IP of THIS machine on your LAN (IPv4)."
SRC_DEF=$(env_get SOURCE_IP)
[ -n "$SRC_DEF" ] || { [ "$NATS_MODE" = "install" ] && SRC_DEF="$NATS_HOST"; } || true
[ -n "$SRC_DEF" ] || SRC_DEF=$(detect_host_ip)
SOURCE_IP_V=""
TRIES=0
while true; do
    ask "This machine's IP" "$SRC_DEF"; SOURCE_IP_V="$REPLY"
    if valid_ipv4 "$SOURCE_IP_V"; then break; fi
    TRIES=$((TRIES + 1))
    if [ "$INTERACTIVE" != true ] || [ "$TRIES" -ge 5 ]; then
        warn "No valid IPv4 address for this machine (got '${SOURCE_IP_V}'). Set it later in the web UI (Settings → \"This engine's IP\") or as SOURCE_IP in .env — until then frames cannot be published."
        SOURCE_IP_V=""; break
    fi
    warn "'${SOURCE_IP_V}' is not a valid IPv4 address (example: 192.168.18.50)."
done
if [ -n "$SOURCE_IP_V" ]; then env_set SOURCE_IP "$SOURCE_IP_V"; ok "Engine source IP: ${SOURCE_IP_V}"; fi

# ---------- 3c. HTTPS ----------
echo ""
echo "── 4/4  HTTPS for the web UI ────────────────────────────────"
echo "    1) Self-signed certificate, generated on this machine (browsers ask you to accept it once)"
echo "    2) My own certificate files (PEM certificate + key)"
echo "    3) Off: plain HTTP (only on a trusted, isolated network)"
TLS_CUR=$(env_get TLS_MODE)
case "$TLS_CUR" in self-signed) TLS_DEF=1 ;; files) TLS_DEF=2 ;; off) TLS_DEF=3 ;; *) TLS_DEF=1 ;; esac
ask "Choose 1, 2 or 3" "$TLS_DEF"
mkdir -p certs
case "$REPLY" in
    2)
        ask "Path to the certificate (PEM, full chain)" ""; CERT_SRC="$REPLY"
        ask "Path to the private key (PEM)" ""; KEY_SRC="$REPLY"
        if [ -f "$CERT_SRC" ] && [ -f "$KEY_SRC" ]; then
            install -m 0644 "$CERT_SRC" certs/tls.crt
            install -m 0600 "$KEY_SRC" certs/tls.key
            # the engine runs as a non-root user inside the container: it must be able to read the key
            chown 10001:10001 certs/tls.key 2>/dev/null || chmod 0644 certs/tls.key
            env_set TLS_MODE files
            env_set TLS_CERT_FILE /app/certs/tls.crt
            env_set TLS_KEY_FILE /app/certs/tls.key
            ok "HTTPS with your certificate."
        else
            warn "Certificate or key not found - using a self-signed certificate instead."
            env_set TLS_MODE self-signed
        fi ;;
    3) env_set TLS_MODE off; warn "HTTPS is off: passwords and session cookies travel in clear text on the network." ;;
    *) env_set TLS_MODE self-signed; [ -z "$(env_get TLS_SANS)" ] && [ -n "$SOURCE_IP_V" ] && env_set TLS_SANS "$SOURCE_IP_V"; ok "HTTPS with a self-signed certificate." ;;
esac
TLS_MODE_V=$(env_get TLS_MODE)
SCHEME=http; [ "$TLS_MODE_V" = "off" ] || SCHEME=https

# ---------- 4. Install NATS (option 2) ----------
if [ "$NATS_MODE" = "install" ]; then
    echo ""
    info "Installing NATS (bundled nats-deploy) ..."
    bash nats-deploy/deploy.sh || err "The bundled NATS install failed — see the output above. Nothing else was changed. Fix that (or re-run and choose option 1/3), then re-run deploy.sh."
fi

# ---------- 5. Build & start the engine ----------
echo ""
if [ "$OFFLINE" = true ]; then
    info "Starting the engine from the offline image (nothing is built or downloaded) ..."
    docker compose up -d --no-build
else
    info "Building and starting the engine (first build downloads base images - this can take a few minutes) ..."
    docker compose up -d --build
fi
if [ "$OFFLINE" = true ]; then ok "Container started."; else ok "Container built and started."; fi

RESTART_POLICY=$(docker inspect -f '{{.HostConfig.RestartPolicy.Name}}' "$CONTAINER_NAME" 2>/dev/null || echo "")
if [ "$RESTART_POLICY" = "always" ]; then
    ok "Restart policy is 'always' — restarts automatically on crash or Docker daemon restart."
else
    warn "Unexpected restart policy: '${RESTART_POLICY:-none}'"
fi
if command -v systemctl >/dev/null 2>&1 && systemctl is-enabled docker >/dev/null 2>&1; then
    ok "Docker is enabled to start on boot — this deployment will survive host reboots."
else
    warn "Could not confirm Docker starts on boot. If needed: sudo systemctl enable docker"
fi

# ---------- 5b. Host helper: rtsp-engine-ctl ----------
# Changes the container's CPU / memory limit from the host (the engine itself has no Docker access, by design).
# Installed as a symlink to the script in this folder, so it always knows which install it belongs to.
if [ -f rtsp-engine-ctl ]; then
    chmod +x rtsp-engine-ctl 2>/dev/null || true
    CTL_LINK=/usr/local/bin/rtsp-engine-ctl
    echo ""
    if [ "$(readlink -f "$CTL_LINK" 2>/dev/null)" = "$SCRIPT_DIR/rtsp-engine-ctl" ]; then
        ok "rtsp-engine-ctl is already installed (${CTL_LINK})."
    else
        ask "Install the 'rtsp-engine-ctl' helper to /usr/local/bin (change CPU/memory limits with one command)? (y/n)" "y"
        case "$REPLY" in
            y|Y|yes|YES)
                if [ -d /usr/local/bin ] && { [ -w /usr/local/bin ] || [ "$(id -u)" -eq 0 ]; }; then
                    ln -sf "$SCRIPT_DIR/rtsp-engine-ctl" "$CTL_LINK" && ok "Installed ${CTL_LINK}  (try: rtsp-engine-ctl status)"                         || warn "Could not create ${CTL_LINK}. Run it from this folder instead: ./rtsp-engine-ctl status"
                elif command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null; then
                    sudo ln -sf "$SCRIPT_DIR/rtsp-engine-ctl" "$CTL_LINK" && ok "Installed ${CTL_LINK}  (try: rtsp-engine-ctl status)"                         || warn "Could not create ${CTL_LINK}. Run it from this folder instead: ./rtsp-engine-ctl status"
                else
                    warn "Not allowed to write /usr/local/bin. To install it: sudo ln -sf '${SCRIPT_DIR}/rtsp-engine-ctl' ${CTL_LINK}"
                fi ;;
            *) info "Skipped. Run it from this folder when needed: ./rtsp-engine-ctl status" ;;
        esac
    fi
fi

# ---------- 6. Wait for health ----------
BASE="http://localhost:${HOST_PORT}"   # plain HTTP keeps answering /api/health when HTTPS is on
HEALTHY=false
for _ in $(seq 1 30); do
    if curl --noproxy "*" -sf "${BASE}/api/health" >/dev/null 2>&1; then HEALTHY=true; break; fi
    sleep 2
done
if [ "$HEALTHY" = true ]; then
    ok "Health check passed — engine is live at ${BASE}"
else
    warn "Health check not responding after 60s. Check: docker compose logs -f"
fi

# ---------- 7. Admin account and NATS (through the engine's CLI inside the container) ----------
# The web API needs a signed-in admin for this, so the installer uses the break-glass CLI
# (`rtsp-engine admin ...`) via docker exec: same database, no network exposure, and secrets
# go in on stdin (never on the command line, never into .env).
engine_cli() { docker exec -i "$CONTAINER_NAME" /app/rtsp-engine admin "$@"; }

ADMIN_PW_SHOWN=""
if [ "$HEALTHY" = true ]; then
    ADMIN_PW=$(od -An -N15 -tx1 /dev/urandom | tr -d ' \n')
    BOOT=$(printf '%s\n' "$ADMIN_PW" | engine_cli bootstrap --password-stdin 2>/dev/null | tail -1 || true)
    case "$BOOT" in
        created|set) ADMIN_PW_SHOWN="$ADMIN_PW"; ok "Initial admin account prepared." ;;
        unchanged)   ok "Admin account already set up (kept as is)." ;;
        *)           warn "Could not prepare the admin account automatically. Run: docker exec -it ${CONTAINER_NAME} /app/rtsp-engine admin reset-password admin" ;;
    esac
    unset ADMIN_PW
fi

if [ "$HEALTHY" = true ] && { [ "$NATS_MODE" = "existing" ] || [ "$NATS_MODE" = "install" ]; }; then
    info "Connecting the engine to NATS at ${NATS_HOST}:${NATS_PORT_V} ..."
    NATS_ARGS=(set-nats --host "$NATS_HOST" --port "$NATS_PORT_V")
    # A username without a password is a token (a secret): it goes through stdin,
    # never on the command line, so it doesn't show in the host's process list.
    if [ -n "$NATS_USER" ] && [ -z "$NATS_PASS" ]; then
        NATS_ARGS+=(--token-stdin); NATS_SECRET="$NATS_USER"
    else
        [ -n "$NATS_USER" ] && NATS_ARGS+=(--user "$NATS_USER")
        NATS_ARGS+=(--password-stdin); NATS_SECRET="$NATS_PASS"
    fi
    if OUT=$(printf '%s\n' "$NATS_SECRET" | engine_cli "${NATS_ARGS[@]}" 2>&1); then
        ok "NATS connected and verified (JetStream streams ready)."
    else
        warn "Could not connect to NATS: $(tail -1 <<< "$OUT" | sed 's/^error: //')"
        warn "Everything else is running. Fix the details in the web UI (Settings, as admin) or with: docker exec -it ${CONTAINER_NAME} /app/rtsp-engine admin set-nats --host <ip>"
    fi
    unset NATS_PASS NATS_SECRET
elif [ "$HEALTHY" = true ] && [ "$NATS_MODE" = "skip" ]; then
    warn "NATS not configured here — sign in to the web UI as admin; it asks for the NATS host/port."
fi

HOST_IP=$(detect_host_ip)
echo ""
ok "Deployment complete."
echo "    Web UI : ${SCHEME}://${HOST_IP:-<this-host-ip>}:${HOST_PORT}"
if [ "$SCHEME" = https ]; then
    FP=$(docker logs "$CONTAINER_NAME" 2>&1 | sed -n 's/.*certificate SHA-256 \([0-9A-F]*\).*/\1/p' | tail -1)
    [ -n "$FP" ] && echo "    Cert   : SHA-256 ${FP}  (compare with what the browser shows before accepting)"
fi
if [ -n "$ADMIN_PW_SHOWN" ]; then
    echo ""
    echo "    ┌─ Sign in ─────────────────────────────────────────────────────────"
    echo "    │  Username : admin"
    echo "    │  Password : ${ADMIN_PW_SHOWN}"
    echo "    │  This is shown only once and must be changed at the first sign-in."
    echo "    │  Lost it?  docker exec -it ${CONTAINER_NAME} /app/rtsp-engine admin reset-password admin"
    echo "    └───────────────────────────────────────────────────────────────────"
    unset ADMIN_PW_SHOWN
fi
echo ""
echo "    Logs   : docker compose logs -f"
echo "    Stop   : docker compose down        (data volumes are kept)"
echo "    Admin  : docker exec -it ${CONTAINER_NAME} /app/rtsp-engine admin help"
echo ""
echo "    Recommended firewall rules (not applied - review and adapt to your network):"
echo "      sudo ufw allow from <operator-subnet> to any port ${HOST_PORT} proto tcp    # web UI"
[ "$NATS_MODE" = "install" ] && echo "      sudo ufw allow from <engine/worker-subnet> to any port ${NATS_PORT_V} proto tcp  # NATS"
echo "      Binding to one interface only: set BIND_ADDR=<this-lan-ip> in .env and re-run deploy.sh"
chmod 600 .env 2>/dev/null || true
[ -f nats-deploy/.env ] && chmod 600 nats-deploy/.env 2>/dev/null || true
warn "If the port is unreachable after a host reboot on some setups, run once: sudo bash setup-docker.sh (edits /etc/docker/daemon.json, restarts Docker host-wide — opt-in)."

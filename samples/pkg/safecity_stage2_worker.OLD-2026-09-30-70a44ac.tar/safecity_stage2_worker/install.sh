#!/usr/bin/env bash
# STUB of the real install.sh (installer test)
echo "[stub-install] args: $* admin_user=${S2_ADMIN_USER:-} admin_pass=${S2_ADMIN_PASS:-}"
printf '#!/usr/bin/env bash\necho "stage2-ctl $1 (stub)"\n' > /usr/local/bin/stage2-ctl; chmod +x /usr/local/bin/stage2-ctl

#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# SafeCity Stage 2 detection stack - guided deploy
# (NATS -> OpenVINO worker -> PostgreSQL -> dashboard + per-camera retention)
#
#   tar -xzf safecity_stage2_worker.tar.gz
#   cd safecity_stage2_worker
#   sudo bash deploy.sh
#
# Asks for the dashboard address, the NATS source, the detection mode, the two
# ports and the database password (press Enter to accept the suggestion in
# [brackets]), then installs Docker if it is missing, loads the images, writes
# the config and starts the stack. Re-run it any time to change ports, NATS or
# credentials; your answers from the last run are offered as the new defaults.
#
#   sudo bash deploy.sh -y     no questions - use the suggestions / current settings
#   sudo bash deploy.sh -n     dry run - ask, check the ports, show the plan, install nothing
#   sudo bash deploy.sh --nats-url nats://10.0.0.5:4222 -y   unattended first install
#
# Ports are checked against everything already running on the machine. A busy port is
# never freed up: deploy.sh suggests the nearest free one and leaves other services alone.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="/opt/safecity_stage2_worker"
ENV_FILE="${APP_DIR}/.env"
CTL="stage2-ctl"

ASSUME_YES=0
DRY_RUN=0
ARG_NATS_URL=""
ORIG_ARGS=("$@")
while [ $# -gt 0 ]; do
  case "$1" in
    -y|--yes)     ASSUME_YES=1 ;;
    -n|--dry-run) DRY_RUN=1 ;;
    --nats-url)   [ $# -ge 2 ] || { echo "--nats-url needs a value" >&2; exit 2; }; ARG_NATS_URL="$2"; shift ;;
    -h|--help)    sed -n '2,22p' "$0"; exit 0 ;;
    *) echo "unknown option: $1  (try -h)" >&2; exit 2 ;;
  esac
  shift
done

say()  { printf '\033[1;32m[deploy]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[warn]\033[0m %s\n'   "$*"; }
die()  { printf '\033[1;31m[error]\033[0m %s\n'  "$*" >&2; exit 1; }

if [ "$(id -u)" -ne 0 ]; then
  command -v sudo >/dev/null 2>&1 || die "run as root:  su -c 'bash $0'"
  exec sudo bash "$0" ${ORIG_ARGS[@]+"${ORIG_ARGS[@]}"}
fi
[ "$(uname -s)" = "Linux" ] || die "deploy.sh is for Linux. On Windows/macOS use windows/load-and-run.ps1"
[ -f "${BUNDLE_DIR}/install.sh" ] && [ -f "${BUNDLE_DIR}/compose/.env.example" ] \
  || die "install.sh / compose/ not found next to deploy.sh - run it from the extracted bundle folder"

# ── helpers ────────────────────────────────────────────────────────────────
# Values shipped in .env.example that must never be kept as a real setting: the example's
# NATS URL points at a development host, and yolo_pass is a published default password.
is_placeholder() {
  case "$1:$2" in
    *:YOUR_*|NATS_URL:nats://root@192.168.18.106:4222|POSTGRES_PASSWORD:yolo_pass) return 0 ;;
  esac
  return 1
}

# current value of KEY in the existing .env (empty if unset or still a template placeholder)
cur() {
  local v=""
  [ -f "$ENV_FILE" ] && v="$(grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2- || true)"
  is_placeholder "$1" "$v" && v=""
  printf '%s' "$v"
}

# same, with a fallback default
curd() { local v; v="$(cur "$1")"; printf '%s' "${v:-$2}"; }

# set KEY=VALUE in a file (replace the line, or append). Value goes through ENVIRON so
# characters like / & \ are safe.
setenv() {
  local f="$1" tmp; tmp="$(mktemp)"
  K="$2" V="$3" awk 'BEGIN{k=ENVIRON["K"]; v=ENVIRON["V"]; d=0}
    index($0, k"=")==1 { print k"="v; d=1; next }
    { print }
    END { if (!d) print k"="v }' "$f" >"$tmp"
  cat "$tmp" >"$f"; rm -f "$tmp"
}

gen() { head -c48 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c20; }

# ask VAR "Question" "default" [secret]   - Enter (or -y) keeps the default
ask() {
  local __var="$1" __q="$2" __def="$3" __secret="${4:-}" __ans=""
  if [ "$ASSUME_YES" -eq 0 ]; then
    if [ -n "$__def" ]; then printf '  %s [%s]: ' "$__q" "$__def" >&2; else printf '  %s: ' "$__q" >&2; fi
    if [ "$__secret" = secret ] && [ -t 0 ]; then IFS= read -rs __ans || true; echo >&2
    else IFS= read -r __ans || true; fi
  fi
  printf -v "$__var" '%s' "${__ans:-$__def}"
}

# ── port check ─────────────────────────────────────────────────────────────
# Read-only: it looks at what is listening / published on this machine and never stops,
# removes or reconfigures anything that is not this stack. This stack's own containers
# (when re-deploying) count as free; every other service counts as taken.
OWN_CONTAINERS=(
  "$(curd POSTGRES_CONTAINER_NAME yolo_postgres_stage2)"
  "$(curd DASHBOARD_CONTAINER_NAME yolo_event_viewer_stage2)"
  "$(curd WORKER_CONTAINER_NAME yolo_ov_nats_worker_stage2)"
  "$(curd HELPER_CONTAINER_NAME yolo_helper_per_camera_retention_stage2)"
  "$(curd CONFIGURATOR_CONTAINER_NAME yolo_stage2_configurator)"
)
PICKER="${BUNDLE_DIR}/compose/pick_ports.py"
CONTAINER_ARGS=(); for c in "${OWN_CONTAINERS[@]}"; do CONTAINER_ARGS+=(--container "$c"); done
CHOSEN_ARGS=()      # --set NAME=PORT for every port already answered, so they stay distinct
PY=""; command -v python3 >/dev/null 2>&1 && [ -f "$PICKER" ] && PY=python3
PICK_ENV="$ENV_FILE"; [ -f "$PICK_ENV" ] || PICK_ENV="${BUNDLE_DIR}/compose/.env.example"

port_busy_fallback() {   # no python3: look at listeners and other containers' published ports
  local p="$1" own
  { ss -H -ltn 2>/dev/null || netstat -ltn 2>/dev/null; } | grep -Eq "[:.]${p}[[:space:]]" || return 1
  # It is listening. It is ours only if one of our containers publishes it.
  if command -v docker >/dev/null 2>&1; then
    for own in "${OWN_CONTAINERS[@]}"; do
      docker port "$own" 2>/dev/null | grep -Eq ":${p}\$" && return 1
    done
  fi
  return 0
}

# pick_one NAME WANT -> prints WANT if it can be used, else the nearest free port above it
pick_one() {
  local name="$1" want="$2" out="" c r
  if [ -n "$PY" ]; then
    out="$("$PY" "$PICKER" --env "$PICK_ENV" --json --probe bind "${CONTAINER_ARGS[@]}" \
             ${CHOSEN_ARGS[@]+"${CHOSEN_ARGS[@]}"} --set "${name}=${want}" 2>/dev/null \
           | "$PY" -c 'import json,sys; print(json.load(sys.stdin)["ports"][sys.argv[1]])' "$name" 2>/dev/null)" || out=""
    [ -n "$out" ] && { printf '%s' "$out"; return 0; }
  fi
  c="$want"
  while [ "$c" -le 65535 ]; do
    r=0
    for u in ${CHOSEN_ARGS[@]+"${CHOSEN_ARGS[@]}"}; do [ "${u#*=}" = "$c" ] && r=1; done
    if [ "$r" -eq 0 ] && ! port_busy_fallback "$c"; then printf '%s' "$c"; return 0; fi
    c=$((c + 1))
  done
  die "no free port found above $want"
}

ask_port() {   # ask_port VAR NAME "Question" default
  local __var="$1" __name="$2" __q="$3" want="$4" sugg ans chk
  while :; do
    sugg="$(pick_one "$__name" "$want")"
    [ "$sugg" != "$want" ] && echo "    port $want is not available here (in use by another service) - suggesting $sugg" >&2
    ask ans "$__q" "$sugg"
    if ! [[ "$ans" =~ ^[0-9]+$ ]] || [ "$ans" -lt 1 ] || [ "$ans" -gt 65535 ]; then
      [ "$ASSUME_YES" -eq 1 ] && die "invalid port: $ans"
      echo "    enter a number from 1 to 65535" >&2; want="$sugg"; continue
    fi
    chk="$(pick_one "$__name" "$ans")"
    [ "$chk" = "$ans" ] && break
    [ "$ASSUME_YES" -eq 1 ] && die "port $ans is not available"
    echo "    $ans is not available (in use by another service) - nothing was touched. Pick another, or Enter for $chk." >&2
    want="$ans"
  done
  printf -v "$__var" '%s' "$ans"
  CHOSEN_ARGS+=(--set "${__name}=${ans}")
}

# LAN address of this machine: the default-route NIC, never docker0/br-*/veth* ...
detect_ip() {
  local ip="" line dev
  line="$(ip -4 route get 1.1.1.1 2>/dev/null | head -1 || true)"
  dev="$(printf '%s' "$line" | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1);exit}}')"
  case "$dev" in
    ""|lo|docker*|br-*|veth*|virbr*|tun*|tap*|tailscale*|wg*|cni*|flannel*|cali*|kube*|lxc*|lxd*) ;;
    *) ip="$(printf '%s' "$line" | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1);exit}}')" ;;
  esac
  printf '%s' "$ip"
}

# ── questions ──────────────────────────────────────────────────────────────
echo
say "SafeCity Stage 2 detection stack - guided deploy"
[ -f "$ENV_FILE" ] && say "found an existing install: its settings are offered as the defaults"
[ "$ASSUME_YES" -eq 0 ] && echo "    Press Enter to accept the value in [brackets]." >&2
echo

echo "  Address people use to open the dashboard (an IP or a DNS name; only used for the printed URL):" >&2
ask HOST "Server address" "$(detect_ip)"
[ -n "$HOST" ] || HOST="<server-ip>"
[[ "$HOST" =~ ^[A-Za-z0-9.:_\<\>-]+$ ]] || die "server address has odd characters: $HOST"

echo "  NATS server the worker reads camera frames from (nats://[user[:pass]@]host:port):" >&2
DEF_NATS="${ARG_NATS_URL:-$(cur NATS_URL)}"
while :; do
  ask NATS_URL "NATS URL" "$DEF_NATS"
  if [[ "$NATS_URL" =~ ^(nats|tls|ws|wss)://[^[:space:]]{1,480}$ ]]; then break; fi
  [ "$ASSUME_YES" -eq 1 ] && die "a NATS URL is required on a first install: sudo bash deploy.sh --nats-url nats://<host>:4222 -y"
  echo "    enter a URL like nats://10.0.0.5:4222" >&2
done
ask NATS_SUBJECT "Frame subject"    "$(curd NATS_SUBJECT 'frames.v2.>')"
[[ "$NATS_SUBJECT" =~ ^frames\.v2[.\>][^[:space:]]{0,480}$ ]] || die "subject must start with frames.v2. (e.g. frames.v2.>)"
ask NATS_QUEUE   "Queue group"      "$(curd NATS_QUEUE stage2_yolo_test)"
[[ "$NATS_QUEUE" =~ ^[A-Za-z0-9._-]*$ ]] || die "queue group may only use letters, digits . _ -"

# Once the configurator has applied a model/classes, its active.json overrides the .env model and
# rules - so asking here would change nothing. Point there instead.
if [ -f "${APP_DIR}/data/stage2_config/active.json" ]; then
  echo "  Detection model and classes: managed from the configurator (unchanged here)." >&2
  RULES="$(curd DETECTION_RULES /app/config/detection_rules.person.json)"
  MODE="configurator"
else
  # detection_rules.json is the person profile too, so there are two real starting sets; any other
  # class selection (or a custom model) is made in the configurator after the install.
  case "$(curd DETECTION_RULES /app/config/detection_rules.person.json)" in
    *vehicle*) DEF_MODE=vehicle ;; *) DEF_MODE=person ;;
  esac
  while :; do
    ask MODE "Starting detection classes (person / vehicle - more in the configurator)" "$DEF_MODE"
    case "$MODE" in person|vehicle) break ;; esac
    [ "$ASSUME_YES" -eq 1 ] && die "invalid detection mode: $MODE"
    echo "    type person or vehicle" >&2
  done
  RULES="/app/config/detection_rules.${MODE}.json"
fi

echo "  Ports - each is checked against what is already running here; a busy one is never touched, a free one is suggested:" >&2
ask_port PORT_DASH DASHBOARD_PORT       "Dashboard port (TCP)"               "$(curd DASHBOARD_PORT 18088)"
ask_port PORT_CFG  CONFIGURATOR_PORT    "Configurator (admin) port (TCP)"    "$(curd CONFIGURATOR_PORT 18090)"
ask_port PORT_PG   POSTGRES_PUBLIC_PORT "PostgreSQL external port (TCP)"     "$(curd POSTGRES_PUBLIC_PORT 15432)"

# PostgreSQL reads POSTGRES_PASSWORD only when it initialises an EMPTY data directory, so
# once the database exists the password cannot be changed from here (the registry marks it
# locked for the same reason).
PG_USER="$(curd POSTGRES_USER yolo)"
PG_DB="$(curd POSTGRES_DB yolo_events)"
PG_INITIALISED=0; [ -f "${APP_DIR}/data/postgres/PG_VERSION" ] && PG_INITIALISED=1
PG_PASS=""
if [ "$PG_INITIALISED" -eq 1 ]; then
  PG_PASS="$(grep -E '^POSTGRES_PASSWORD=' "$ENV_FILE" 2>/dev/null | tail -n1 | cut -d= -f2- || true)"
  echo "  Database: already initialised - keeping its current password (user ${PG_USER})." >&2
  [ "$PG_PASS" = "yolo_pass" ] && warn "the database still uses the published default password 'yolo_pass'; rotate it manually (ALTER USER) and update POSTGRES_PASSWORD + PG_CONN in $ENV_FILE"
else
  echo "  Database login (used by the worker, dashboard and retention helper; also for external SQL access):" >&2
  if [ -n "$(cur POSTGRES_PASSWORD)" ]; then PASS_HINT="Enter = keep current"; else PASS_HINT="Enter = generate one"; fi
  ask PG_PASS "PostgreSQL password for user ${PG_USER} ($PASS_HINT)" "" secret
  if [ -n "$PG_PASS" ]; then
    [[ "$PG_PASS" =~ ^[A-Za-z0-9._@%+:,-]{8,}$ ]] \
      || die "password: at least 8 characters from letters, digits and . _ @ % + : , -"
  fi
fi

# Configurator (admin page: model library, classes, metrics) login.
ADMIN_FILE="${APP_DIR}/data/stage2_config/admin.json"
DEF_ADMIN="admin"
if [ -f "$ADMIN_FILE" ]; then
  DEF_ADMIN="$(sed -n 's/.*"user": *"\([^"]*\)".*/\1/p' "$ADMIN_FILE" | head -n1)"; DEF_ADMIN="${DEF_ADMIN:-admin}"
fi
echo "  Configurator login (admin page for models, classes and metrics):" >&2
ask CFG_USER "Admin username" "$DEF_ADMIN"
[[ "$CFG_USER" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || die "username may only use letters, digits . _ -"
if [ -f "$ADMIN_FILE" ]; then CFG_HINT="Enter = keep current"; else CFG_HINT="Enter = generate one"; fi
ask CFG_PASS "Admin password ($CFG_HINT)" "" secret
if [ -n "$CFG_PASS" ] && [ "${#CFG_PASS}" -lt 8 ]; then die "admin password: at least 8 characters"; fi
CFG_GENERATED=0
if [ -z "$CFG_PASS" ] && { [ ! -f "$ADMIN_FILE" ] || [ "$CFG_USER" != "$DEF_ADMIN" ]; }; then
  CFG_PASS="$(gen)"; CFG_GENERATED=1
fi

echo
say "about to install with:"
printf '    dashboard     http://%s:%s\n    configurator  http://%s:%s  (admin: %s)\n    NATS          %s  subject %s  queue %s\n    mode          %s\n    postgres      %s/tcp (user %s, db %s)\n    folder        %s\n\n' \
  "$HOST" "$PORT_DASH" "$HOST" "$PORT_CFG" "$CFG_USER" "$(printf '%s' "$NATS_URL" | sed -E 's#//[^@/]*@#//***@#')" "$NATS_SUBJECT" "${NATS_QUEUE:-<broadcast>}" \
  "$MODE" "$PORT_PG" "$PG_USER" "$PG_DB" "$APP_DIR"
if [ "$DRY_RUN" -eq 1 ]; then say "dry run - nothing was installed or changed"; exit 0; fi
ask GO "Continue? (y/n)" "y"
case "$GO" in n|N|no|NO) echo "cancelled - nothing changed"; exit 0 ;; esac

# ── write the config, then let install.sh do the heavy lifting ─────────────
mkdir -p "$APP_DIR"
if [ ! -f "$ENV_FILE" ]; then cp "${BUNDLE_DIR}/compose/.env.example" "$ENV_FILE"; fi
chmod 600 "$ENV_FILE"

GENERATED=0
if [ -z "$PG_PASS" ]; then PG_PASS="$(cur POSTGRES_PASSWORD)"; fi
if [ -z "$PG_PASS" ]; then PG_PASS="$(gen)"; GENERATED=1; fi

setenv "$ENV_FILE" NATS_URL             "$NATS_URL"
setenv "$ENV_FILE" NATS_SUBJECT         "$NATS_SUBJECT"
setenv "$ENV_FILE" NATS_QUEUE           "$NATS_QUEUE"
setenv "$ENV_FILE" DETECTION_RULES      "$RULES"
setenv "$ENV_FILE" DASHBOARD_PORT       "$PORT_DASH"
setenv "$ENV_FILE" CONFIGURATOR_PORT    "$PORT_CFG"
setenv "$ENV_FILE" POSTGRES_PUBLIC_PORT "$PORT_PG"
setenv "$ENV_FILE" POSTGRES_USER        "$PG_USER"
setenv "$ENV_FILE" POSTGRES_DB          "$PG_DB"
setenv "$ENV_FILE" POSTGRES_PASSWORD    "$PG_PASS"
setenv "$ENV_FILE" PG_CONN              "host=postgres port=5432 dbname=${PG_DB} user=${PG_USER} password=${PG_PASS}"
# Always seed the dashboard token, even while VIEWER_AUTH_ENABLED=0: switching the guard on
# later with an empty token would lock every client out (it fails closed).
[ -n "$(cur VIEWER_API_TOKEN)" ] || setenv "$ENV_FILE" VIEWER_API_TOKEN "$(gen)"

say "installing (Docker if missing, the images, config, port check)..."
S2_ADMIN_USER="$CFG_USER" S2_ADMIN_PASS="$CFG_PASS" bash "${BUNDLE_DIR}/install.sh" --no-start

# install.sh may have moved a busy port - read back what is really in .env
FINAL_DASH="$(cur DASHBOARD_PORT)"; FINAL_PG="$(cur POSTGRES_PUBLIC_PORT)"; FINAL_CFG="$(cur CONFIGURATOR_PORT)"
for pair in "Dashboard:$PORT_DASH:$FINAL_DASH" "Configurator:$PORT_CFG:$FINAL_CFG" "PostgreSQL:$PORT_PG:$FINAL_PG"; do
  IFS=: read -r name want got <<<"$pair"
  [ "$want" = "$got" ] || warn "$name port $want was busy - using $got instead"
done

# ── start and wait until it answers ────────────────────────────────────────
say "starting the stack..."
"$CTL" start || die "start failed - see: $CTL logs"

# Probed from inside the containers (stage2-ctl health), and the worker's readiness is read
# only from its CURRENT run's log - Docker keeps the previous run's output.
READY=0
for _ in $(seq 1 60); do
  if "$CTL" health >/dev/null 2>&1; then READY=1; break; fi
  sleep 1
done

echo
if [ "$READY" -eq 1 ]; then
  say "stack is up: database, dashboard and worker all answer"
else
  warn "started, but not everything was healthy within 60 s:"
  "$CTL" health || true
  warn "the most common cause is an unreachable NATS server - check: $CTL logs worker"
fi
echo
echo "  Dashboard     http://${HOST}:${FINAL_DASH}"
echo "  Configurator  http://${HOST}:${FINAL_CFG}   (models, classes, metrics)"
if [ "$CFG_GENERATED" = 1 ]; then
  echo "  Admin login   ${CFG_USER} / ${CFG_PASS}   (generated - shown once; change it on the Account page)"
elif [ -n "$CFG_PASS" ]; then
  echo "  Admin login   ${CFG_USER} / (the password you entered)"
else
  echo "  Admin login   unchanged"
fi
echo "  PostgreSQL  ${HOST}:${FINAL_PG}   user ${PG_USER} / db ${PG_DB}"
if [ "$GENERATED" = 1 ]; then
  echo "  DB password ${PG_PASS}   (generated - shown once; saved in $ENV_FILE)"
else
  echo "  DB password unchanged (in $ENV_FILE)"
fi
echo "  Config      $ENV_FILE   (edit, then: $CTL update)"
echo "  Manage      $CTL {status|logs|health|restart|stop|start|update}"
echo "  Remove      sudo bash ${BUNDLE_DIR}/uninstall.sh   (--purge, --remove-docker)"
echo

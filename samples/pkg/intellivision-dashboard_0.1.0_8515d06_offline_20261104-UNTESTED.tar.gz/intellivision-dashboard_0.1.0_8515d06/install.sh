#!/usr/bin/env bash
set -e
echo "Installing dashboard (sample)"
sleep 1
echo "Pulling images..."
sleep 1
echo "Done"

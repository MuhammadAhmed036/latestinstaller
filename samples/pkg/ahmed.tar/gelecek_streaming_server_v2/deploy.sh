#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# GELECEK Streaming Server v2 - guided deploy
#
#   tar -xzf gelecek_streaming_server_v2.tar.gz
#   cd gelecek_streaming_server_v2
#   sudo bash deploy.sh
#
# Asks for the server address, the four ports and the API login (press Enter
# to accept the suggestion in [brackets]), then installs Docker if it is
# missing, loads the image, writes the config and starts the server.
# Re-run it any time to change ports or credentials; your answers from the
# last run are offered as the new defaults.
#
#   sudo bash deploy.sh -y     no questions - use the suggestions / current settings
#   sudo bash deploy.sh -n     dry run - ask, check the ports, show the plan, install nothing
#
# Ports are checked against everything already running on the machine. A busy port is
# never freed up: deploy.sh suggests the nearest free one and leaves other services alone.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="/opt/gelecek_streaming_server_v2"
ENV_FILE="${APP_DIR}/.env"

ASSUME_YES=0
DRY_RUN=0
for arg in "$@"; do
  case "$arg" in
    -y|--yes)     ASSUME_YES=1 ;;
    -n|--dry-run) DRY_RUN=1 ;;
    -h|--help)    sed -n '2,19p' "$0"; exit 0 ;;
    *) echo "unknown option: $arg  (try -h)" >&2; exit 2 ;;
  esac
done

say()  { printf '\033[1;32m[deploy]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[warn]\033[0m %s\n'   "$*"; }
die()  { printf '\033[1;31m[error]\033[0m %s\n'  "$*" >&2; exit 1; }

if [ "$(id -u)" -ne 0 ]; then
  command -v sudo >/dev/null 2>&1 || die "run as root:  su -c 'bash $0'"
  exec sudo bash "$0" "$@"
fi
[ "$(uname -s)" = "Linux" ] || die "deploy.sh is for Linux. On Windows use windows/load-and-run.ps1"
[ -f "${BUNDLE_DIR}/install.sh" ] || die "install.sh not found next to deploy.sh - run it from the extracted bundle folder"

# ── helpers ────────────────────────────────────────────────────────────────
# current value of KEY in the existing .env (empty if unset or still a template placeholder)
cur() {
  local v=""
  [ -f "$ENV_FILE" ] && v="$(grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2- || true)"
  case "$v" in YOUR_*) v="" ;; esac
  printf '%s' "$v"
}

# set KEY=VALUE in a file (replace the line, or append). Value goes through ENVIRON so
# characters like / & \ are safe.
setenv() {
  local f="$1" tmp; tmp="$(mktemp)"
  K="$2" V="$3" awk 'BEGIN{k=ENVIRON["K"]; v=ENVIRON["V"]; d=0}
    index($0, k"=")==1 { print k"="v; d=1; next }
    { print }
    END { if (!d) print k"="v }' "$f" >"$tmp"
  cat "$tmp" >"$f"; rm -f "$tmp"
}

# same, with a fallback default
curd() { local v; v="$(cur "$1")"; printf '%s' "${v:-$2}"; }

# ports the server itself uses INSIDE its container (MediaMTX backends + control API). A public
# port with the same number cannot bind there, so they must never be offered to the user.
reserved_ports() { echo "9997 $(curd RTSP_BACKEND_PORT 18554) $(curd WHEP_BACKEND_PORT 18889)"; }

gen() { head -c48 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c20; }

# ask VAR "Question" "default" [secret]   - Enter (or -y) keeps the default
ask() {
  local __var="$1" __q="$2" __def="$3" __secret="${4:-}" __ans=""
  if [ "$ASSUME_YES" -eq 0 ]; then
    if [ -n "$__def" ]; then printf '  %s [%s]: ' "$__q" "$__def" >&2; else printf '  %s: ' "$__q" >&2; fi
    if [ "$__secret" = secret ] && [ -t 0 ]; then IFS= read -rs __ans || true; echo >&2
    else IFS= read -r __ans || true; fi
  fi
  printf -v "$__var" '%s' "${__ans:-$__def}"
}

# ── port check ─────────────────────────────────────────────────────────────
# Read-only: it looks at what is listening / published on this machine and never stops,
# removes or reconfigures anything that is not this stack. This stack's own container
# (when re-deploying) counts as free; every other service counts as taken.
OWN_CONTAINER="gelecek-streaming-server-v2"
PICKER="${BUNDLE_DIR}/compose/pick_ports.py"
CHOSEN_ARGS=()      # --set NAME=PORT for every port already answered, so all four stay distinct
PY=""; command -v python3 >/dev/null 2>&1 && [ -f "$PICKER" ] && PY=python3

port_busy_fallback() {   # no python3: look at listeners and other containers' published ports
  local p="$1"
  { ss -H -ltun 2>/dev/null || netstat -ltun 2>/dev/null; } | grep -Eq "[:.]${p}[[:space:]]" && return 0
  if command -v docker >/dev/null 2>&1; then
    docker ps --format '{{.Names}} {{.Ports}}' 2>/dev/null | grep -v "^${OWN_CONTAINER} " | grep -Eq "(:|-)${p}->" && return 0
  fi
  return 1
}

# pick_one NAME WANT -> prints WANT if it can be used, else the nearest free port above it
pick_one() {
  local name="$1" want="$2" out="" c r
  if [ -n "$PY" ]; then
    out="$("$PY" "$PICKER" --env "$ENV_FILE" --json --container "$OWN_CONTAINER" \
             ${CHOSEN_ARGS[@]+"${CHOSEN_ARGS[@]}"} --set "${name}=${want}" 2>/dev/null \
           | "$PY" -c 'import json,sys; print(json.load(sys.stdin)["ports"][sys.argv[1]])' "$name" 2>/dev/null)" || out=""
    [ -n "$out" ] && { printf '%s' "$out"; return 0; }
  fi
  c="$want"
  while [ "$c" -le 65535 ]; do
    r=0
    case " $(reserved_ports) " in *" $c "*) r=1 ;; esac
    for u in ${CHOSEN_ARGS[@]+"${CHOSEN_ARGS[@]}"}; do [ "${u#*=}" = "$c" ] && r=1; done
    if [ "$r" -eq 0 ] && ! port_busy_fallback "$c"; then printf '%s' "$c"; return 0; fi
    c=$((c + 1))
  done
  die "no free port found above $want"
}

ask_port() {   # ask_port VAR NAME "Question" default
  local __var="$1" __name="$2" __q="$3" want="$4" sugg ans chk
  while :; do
    sugg="$(pick_one "$__name" "$want")"
    [ "$sugg" != "$want" ] && echo "    port $want is not available here (in use by another service, or reserved) - suggesting $sugg" >&2
    ask ans "$__q" "$sugg"
    if ! [[ "$ans" =~ ^[0-9]+$ ]] || [ "$ans" -lt 1 ] || [ "$ans" -gt 65535 ]; then
      [ "$ASSUME_YES" -eq 1 ] && die "invalid port: $ans"
      echo "    enter a number from 1 to 65535" >&2; want="$sugg"; continue
    fi
    chk="$(pick_one "$__name" "$ans")"
    [ "$chk" = "$ans" ] && break
    [ "$ASSUME_YES" -eq 1 ] && die "port $ans is not available"
    echo "    $ans is not available (in use by another service, or used internally) - nothing was touched. Pick another, or Enter for $chk." >&2
    want="$ans"
  done
  printf -v "$__var" '%s' "$ans"
  CHOSEN_ARGS+=(--set "${__name}=${ans}")
}

# LAN address of this machine: the default-route NIC, never docker0/br-*/veth* ...
detect_ip() {
  local ip="" line dev
  if command -v python3 >/dev/null 2>&1 && [ -f "${BUNDLE_DIR}/compose/hostnet.py" ]; then
    ip="$(python3 "${BUNDLE_DIR}/compose/hostnet.py" detect --json 2>/dev/null \
          | python3 -c 'import json,sys; print(json.load(sys.stdin).get("host") or "")' 2>/dev/null || true)"
  fi
  if [ -z "$ip" ]; then
    line="$(ip -4 route get 1.1.1.1 2>/dev/null | head -1 || true)"
    dev="$(printf '%s' "$line" | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1);exit}}')"
    case "$dev" in
      ""|lo|docker*|br-*|veth*|virbr*|tun*|tap*|tailscale*|wg*|cni*|flannel*|cali*|kube*|lxc*|lxd*) ;;
      *) ip="$(printf '%s' "$line" | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1);exit}}')" ;;
    esac
  fi
  printf '%s' "$ip"
}

# ── questions ──────────────────────────────────────────────────────────────
echo
say "GELECEK Streaming Server v2 - guided deploy"
[ -f "$ENV_FILE" ] && say "found an existing install: its settings are offered as the defaults"
[ "$ASSUME_YES" -eq 0 ] && echo "    Press Enter to accept the value in [brackets]." >&2
echo

DEF_HOST="$(cur PUBLIC_HOST)"; [ -n "$DEF_HOST" ] || DEF_HOST="$(detect_ip)"
echo "  Address viewers use to reach this server (an IP or a DNS name):" >&2
ask HOST       "Server address"                 "$DEF_HOST"
[ -n "$HOST" ] || die "no server address - enter the IP or name of this machine"
[[ "$HOST" =~ ^[A-Za-z0-9.,:_-]+$ ]] || die "server address has odd characters: $HOST"

echo "  Ports - each is checked against what is already running here; a busy one is never touched, a free one is suggested:" >&2
ask_port PORT_WEB  WEBCTL_PORT     "Web UI / API port (TCP)"       "$(curd WEBCTL_PORT 8000)"
ask_port PORT_RTSP MTXCTL_PORT    "RTSP port (TCP)"               "$(curd MTXCTL_PORT 8554)"
ask_port PORT_WHEP WHEP_PORT       "WebRTC/WHEP port (TCP)"        "$(curd WHEP_PORT 8889)"
ask_port PORT_ICE  WEBRTC_ICE_PORT "WebRTC media port (UDP+TCP)"   "$(curd WEBRTC_ICE_PORT 8189)"

echo "  API login (HTTP Basic, used by scripts and API clients; the Web UI has its own sign-in):" >&2
ask ADMIN_USER "API username"                   "$(curd ROOT_USER admin)"
[[ "$ADMIN_USER" =~ ^[A-Za-z0-9._-]+$ ]] || die "username may only use letters, digits . _ -"

if [ -n "$(cur ROOT_PASS)" ]; then PASS_HINT="Enter = keep current"; else PASS_HINT="Enter = generate one"; fi
ask ADMIN_PASS "API password ($PASS_HINT)" "" secret
if [ -n "$ADMIN_PASS" ]; then
  [[ "$ADMIN_PASS" =~ ^[A-Za-z0-9._@%+=:,-]{8,}$ ]] \
    || die "password: at least 8 characters from letters, digits and . _ @ % + = : , -"
fi

echo
say "about to install with:"
printf '    address  %s\n    web UI   %s/tcp\n    RTSP     %s/tcp\n    WHEP     %s/tcp\n    media    %s/udp+tcp\n    API user %s\n    folder   %s\n\n' \
  "$HOST" "$PORT_WEB" "$PORT_RTSP" "$PORT_WHEP" "$PORT_ICE" "$ADMIN_USER" "$APP_DIR"
if [ "$DRY_RUN" -eq 1 ]; then say "dry run - nothing was installed or changed"; exit 0; fi
ask GO "Continue? (y/n)" "y"
case "$GO" in n|N|no|NO) echo "cancelled - nothing changed"; exit 0 ;; esac

# ── write the config, then let install.sh do the heavy lifting ─────────────
mkdir -p "$APP_DIR"
if [ ! -f "$ENV_FILE" ]; then cp "${BUNDLE_DIR}/compose/.env.example" "$ENV_FILE"; fi
chmod 600 "$ENV_FILE"

if [ -z "$ADMIN_PASS" ]; then ADMIN_PASS="$(cur ROOT_PASS)"; fi
if [ -z "$ADMIN_PASS" ]; then ADMIN_PASS="$(gen)"; GENERATED=1; else GENERATED=0; fi

setenv "$ENV_FILE" PUBLIC_HOST        "$HOST"
setenv "$ENV_FILE" MTX_PUBLIC_HOST    "$HOST"
setenv "$ENV_FILE" WEBCTL_PORT        "$PORT_WEB"
setenv "$ENV_FILE" MTXCTL_PORT        "$PORT_RTSP"
setenv "$ENV_FILE" WHEP_PORT          "$PORT_WHEP"
setenv "$ENV_FILE" WEBRTC_ICE_PORT    "$PORT_ICE"
setenv "$ENV_FILE" ROOT_USER          "$ADMIN_USER"
setenv "$ENV_FILE" ROOT_PASS          "$ADMIN_PASS"
[ -n "$(cur RTSP_READ_USER)" ]    || setenv "$ENV_FILE" RTSP_READ_USER    luna
[ -n "$(cur RTSP_READ_PASS)" ]    || setenv "$ENV_FILE" RTSP_READ_PASS    "$(gen)"
[ -n "$(cur RTSP_PUBLISH_USER)" ] || setenv "$ENV_FILE" RTSP_PUBLISH_USER publisher
[ -n "$(cur RTSP_PUBLISH_PASS)" ] || setenv "$ENV_FILE" RTSP_PUBLISH_PASS "$(gen)"

say "installing (Docker if missing, the app image, config, port check)..."
bash "${BUNDLE_DIR}/install.sh" --no-start

# install.sh may have moved a busy port - read back what is really in .env
FINAL_WEB="$(cur WEBCTL_PORT)"; FINAL_RTSP="$(cur MTXCTL_PORT)"
FINAL_WHEP="$(cur WHEP_PORT)";  FINAL_ICE="$(cur WEBRTC_ICE_PORT)"
for pair in "Web UI:$PORT_WEB:$FINAL_WEB" "RTSP:$PORT_RTSP:$FINAL_RTSP" "WHEP:$PORT_WHEP:$FINAL_WHEP" "media:$PORT_ICE:$FINAL_ICE"; do
  IFS=: read -r name want got <<<"$pair"
  [ "$want" = "$got" ] || warn "$name port $want was busy - using $got instead"
done

# ── start and wait until it answers ────────────────────────────────────────
say "starting the server..."
gelecek-ctl start || die "start failed - see: gelecek-ctl logs"

# Probed from inside the container (gelecek-ctl health): with API lockdown on,
# the API login is refused from anywhere but the container's own loopback.
READY=0
for _ in $(seq 1 60); do
  if gelecek-ctl health >/dev/null 2>&1; then READY=1; break; fi
  sleep 1
done

echo
if [ "$READY" -eq 1 ]; then say "server is up and answering"; else warn "started, but the Web UI did not answer within 60 s - check: gelecek-ctl logs"; fi
echo
echo "  Web UI    http://${HOST%%,*}:${FINAL_WEB}"
echo "  Web UI    sign in as admin / admin on a fresh install (you must choose a new password straight away)"
echo "  API login ${ADMIN_USER} / ${ADMIN_PASS}$([ "$GENERATED" = 1 ] && echo '   (generated - saved in '"$ENV_FILE"')')"
echo "  RTSP      rtsp://${HOST%%,*}:${FINAL_RTSP}/<stream>"
echo "  Config    $ENV_FILE   (edit, then: gelecek-ctl restart)"
echo "  Manage    gelecek-ctl {status|logs|restart|stop|start|health}"
echo "  Remove    sudo bash ${BUNDLE_DIR}/uninstall.sh --purge"
echo

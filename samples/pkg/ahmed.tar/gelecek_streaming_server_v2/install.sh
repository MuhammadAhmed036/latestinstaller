#!/usr/bin/env bash
# STUB of the real install.sh for installer testing
set -e
echo "[stub-install] args: $*"
mkdir -p /opt/gelecek_streaming_server_v2
[ -f /opt/gelecek_streaming_server_v2/.env ] && echo "[stub-install] .env present, keys: $(grep -c = /opt/gelecek_streaming_server_v2/.env)"
printf '#!/usr/bin/env bash\ncase "$1" in health) echo "{\\"ok\\":true}";; *) echo "gelecek-ctl $1 (stub)";; esac\n' > /usr/local/bin/gelecek-ctl
chmod +x /usr/local/bin/gelecek-ctl
